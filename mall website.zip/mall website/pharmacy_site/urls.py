from django.urls import path
from . import views

urlpatterns = [
    path('',views.pharmacy_home, name='pharmacy-home'),
    path('search/',views.search_product, name='pharmacy-search-product'),
    path('prescriptionUpload/',views.upload_prescription, name='prescription-upload'),
    path('prescriptionCalculate/',views.prescription_calc, name='prescription-calculate'),
    path('presecriptionToCart/',views.cartView, name='prescription-to-cart'),
]
