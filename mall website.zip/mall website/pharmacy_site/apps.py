from django.apps import AppConfig


class PharmacySiteConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pharmacy_site'
