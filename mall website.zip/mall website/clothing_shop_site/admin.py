from django.contrib import admin
from .models import Cloth
# Register your models here.

admin.site.register(Cloth)