from django.urls import path
from . import views

urlpatterns = [
    path('',views.clothing_shop_home, name='clothing-shop-home'),
]
