from django.shortcuts import render
from .models import Cloth
# Create your views here.
def clothing_shop_home(request):
    context={
        'title':'clothing-shop-home',
        'cloths':Cloth.objects.all()[:10],
        'recents':Cloth.objects.order_by('-id')[:10]
    }
    return render(request,'clothing_shop_site/home.html',context)
