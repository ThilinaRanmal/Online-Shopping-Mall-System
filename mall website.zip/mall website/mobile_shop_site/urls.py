from django.urls import path
from . import views

urlpatterns = [
    path('',views.mobile_shop_home, name='mobile-shop-home'),
    path('mobiles-page/',views.mobiles_page, name='mobiles-page'),
    path('search/',views.search_product, name='mobiles-search-product'),
]
